[My English is not good actually. Please correct anything incorrect.]

# What is VimDesktop

VimDesktop = Vim Mode At Desktop

Usages of VIM are really fascinating, every Vimer wants vim-like usage can be used in every single  program. Haven't you using [Vimperator](http://www.vimperator.org/) / [Pentadactyl](http://5digits.org/pentadactyl/) in Firefox, or [vimium](http://vimium.github.io/) in Chrome?

Yes! Yes! Yes!  
2012, a Chinese young guy named **Array** (linxinhong.sky At gmail.com) created **ViATc** (Vim Mode At Total Command) by using [ahk (AutoHotKey)](http://en.wikipedia.org/wiki/AutoHotkey). This 'little' plugin likes wings make Total Command fly like birds. Complex operations can be finished from keyboard. Most functions can be finished by twice(at most) pressings.

2013， ViATc renamed as VimD (Vim Mode At Desktop). It will make us do everything in desktop by using vim-like usage [We hope everything].

# Who should use VimDesktop
- **Vimer**: The guy who obsessed with keyboard and vim-like operation. And want vim-like operation used in every place.
- **Total Commander**: If you are a TC FAN, and consider TC really improved your efficiency. I think you really should try VimDesktop. As so far, TC is the most perfect supported program, VimDesktop is evolved from ViATc after all.
- **User of Vimperator or Pentadactyl**: If the Vimperator or Pentadactyl is the most important reason of using Firefox, you mustn't missing VimDesktop.
- If you don't know what are they all above, and you happened like interesting tools, try VimDesktop!

# What is VimDesktop capable of
Generally, VimDesktop is the tool which can define shortcut easily